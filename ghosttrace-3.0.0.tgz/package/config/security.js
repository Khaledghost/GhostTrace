/**
 * Startup security checks and shared limits.
 */

const WEAK_SECRETS = new Set([
  'super-secret-key-for-dev',
  'super-secret-key-change-this-in-production',
  'change-me-use-openssl-rand-hex-32',
  'change-me-to-a-strong-password',
]);

function validateEnvironment() {
  const warnings = [];
  const errors = [];
  const isProd = process.env.NODE_ENV === 'production';

  const jwt = process.env.JWT_SECRET || '';
  if (!jwt || jwt.length < 32) {
    (isProd ? errors : warnings).push('JWT_SECRET should be at least 32 characters (openssl rand -hex 32)');
  }
  if (WEAK_SECRETS.has(jwt)) {
    (isProd ? errors : warnings).push('JWT_SECRET is a known default — change it before production');
  }

  if (isProd && (process.env.ALLOWED_ORIGINS || '*').trim() === '*') {
    warnings.push('ALLOWED_ORIGINS=* is permissive; set explicit origins in production');
  }

  if (isProd && !process.env.DB_PASS) {
    warnings.push('DB_PASS is empty in production');
  }

  warnings.forEach((w) => console.warn(`  ⚠️  Security: ${w}`));
  if (errors.length) {
    errors.forEach((e) => console.error(`  🛑 Security: ${e}`));
    throw new Error('Security configuration failed — fix environment variables');
  }
}

module.exports = { validateEnvironment };
