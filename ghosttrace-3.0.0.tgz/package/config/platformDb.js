const fs = require('fs');
const path = require('path');
const { encryptSecret, decryptSecret } = require('../utils/secretStore');

const CONFIG_FILE = process.env.PLATFORM_DB_FILE
  || path.join(__dirname, '..', 'data', 'platform-db.json');

function fromEnv() {
  return {
    dialect: 'postgres',
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432', 10),
    database: process.env.DB_NAME || 'dna',
    username: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASS || '',
    ssl: process.env.DB_SSL === 'true',
    connectionMode: process.env.DB_URI ? 'uri' : 'fields',
    connectionString: process.env.DB_URI || process.env.DATABASE_URL || null,
    poolMax: parseInt(process.env.DB_POOL_MAX || '10', 10),
    connectTimeoutMs: parseInt(process.env.DB_CONNECT_TIMEOUT_MS || '30000', 10),
    source: 'env',
  };
}

function loadFileConfig() {
  try {
    if (!fs.existsSync(CONFIG_FILE)) return null;
    const data = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    return {
      ...data,
      password: decryptSecret(data.password),
      connectionString: decryptSecret(data.connectionString),
    };
  } catch (_) {
    return null;
  }
}

function getConfig() {
  const file = loadFileConfig();
  if (file) return { ...fromEnv(), ...file, source: 'file' };
  return fromEnv();
}

function saveConfig(patch) {
  const dir = path.dirname(CONFIG_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const current = getConfig();
  const next = {
    ...current,
    ...patch,
    updatedAt: new Date().toISOString(),
    source: 'file',
  };
  if (patch.password === '' || patch.password === undefined) {
    next.password = current.password;
  }
  const toStore = {
    ...next,
    password: encryptSecret(next.password),
    connectionString: encryptSecret(next.connectionString),
  };
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(toStore, null, 2), 'utf8');
  return sanitizePublic(next);
}

function sanitizePublic(cfg) {
  return {
    dialect: cfg.dialect || 'postgres',
    host: cfg.host,
    port: cfg.port,
    database: cfg.database,
    username: cfg.username,
    ssl: !!cfg.ssl,
    connectionMode: cfg.connectionMode || 'fields',
    hasPassword: !!(cfg.password),
    poolMax: cfg.poolMax,
    connectTimeoutMs: cfg.connectTimeoutMs,
    source: cfg.source,
    connectionString: cfg.connectionMode === 'uri' ? '***' : undefined,
  };
}

function buildSequelizeOptions(cfg) {
  if (cfg.connectionMode === 'uri' && cfg.connectionString) {
    return { url: cfg.connectionString, dialect: 'postgres' };
  }
  return {
    host: cfg.host,
    port: cfg.port,
    database: cfg.database,
    username: cfg.username,
    password: cfg.password,
    dialect: 'postgres',
    dialectOptions: cfg.ssl
      ? { ssl: { require: true, rejectUnauthorized: false } }
      : {},
  };
}

module.exports = {
  getConfig,
  saveConfig,
  sanitizePublic,
  buildSequelizeOptions,
  CONFIG_FILE,
};
