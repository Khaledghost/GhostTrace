# GhostTrace

**Drop-in behavioral detection & response for any Node.js/Express backend**

Add enterprise-grade security monitoring to your application in minutes, not days.

[![npm version](https://badge.fury.io/js/ghosttrace.svg)](https://www.npmjs.com/package/ghosttrace)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## ⚡ Quick Start

### Installation

```bash
npm install ghosttrace
```

### Integration (3 lines of code)

```javascript
const express = require('express');
const ghosttrace = require('ghosttrace');

const app = express();

// Initialize GhostTrace
await ghosttrace.init({
  adminEmail: 'admin@company.com',
  adminPassword: 'secure-password',
  dashboardPort: 3001,
});

// Secure your routes
app.use('/api', ghosttrace.secure());

// Your routes work normally
app.get('/api/users', (req, res) => {
  res.json({ users: [] });
});

app.listen(3000);
```

That's it! Your API is now protected and monitored.

## 🎯 Dashboard

Open `http://localhost:3001` and login with your admin credentials to access:

- 🚨 **Real-time alert queue** - Triage threats as they happen
- 📊 **Behavioral analytics** - Per-entity risk profiles and anomaly detection
- 🎯 **MITRE ATT&CK mapping** - Automatic technique classification
- 🔍 **Threat hunting** - Search alerts by IP, technique, severity
- 🤖 **AI-powered triage** - Multi-provider AI analysis (OpenAI, Claude, Gemini, Ollama)
- 📈 **Risk scoring** - Dynamic threat scoring with Z-score anomaly detection
- 🔒 **Incident management** - Full case management with timeline
- 📋 **Audit trail** - Track all analyst actions
- 🌐 **GeoIP tracking** - Live global threat visualization
- 🔌 **Data source monitoring** - Connect Postgres, MySQL, MongoDB, Redis

![GhostTrace Dashboard](https://via.placeholder.com/800x400?text=GhostTrace+Dashboard)

## 📦 What Gets Protected?

GhostTrace automatically detects and blocks:

- ✅ SQL injection attempts
- ✅ XSS (Cross-site scripting)
- ✅ Brute force attacks
- ✅ Credential stuffing
- ✅ Rate limit violations
- ✅ Behavioral anomalies
- ✅ Velocity attacks
- ✅ Suspicious user agents
- ✅ Known malicious IPs
- ✅ Session hijacking

## ⚙️ Configuration

### Environment Variables

```env
# Required
GHOST_ADMIN_EMAIL=admin@company.com
GHOST_ADMIN_PASS=secure-password

# Optional
GHOST_PORT=3001                    # Dashboard port
GHOST_PROXY=3002                   # Proxy port (if using proxy mode)
GHOST_BLOCK_THRESHOLD=70           # Risk score to block (0-100)
GHOST_RATE_LIMIT=120              # Max requests per minute
GHOST_BLOCK_ON_THREAT=true        # Enable blocking (false = monitor only)

# Database (defaults to auto-created PostgreSQL)
GHOST_DB_TYPE=postgres
GHOST_DB_HOST=localhost
GHOST_DB_PORT=5432
GHOST_DB_NAME=ghosttrace
GHOST_DB_USER=postgres
GHOST_DB_PASS=password
GHOST_DB_SYNC=true                # Auto-create tables

# AI (optional - supports multiple providers)
GHOST_AI_PROVIDER=openai          # openai, anthropic, gemini, ollama
GHOST_AI_KEY=sk-...
GHOST_AI_MODEL=gpt-4o-mini
```

### Programmatic Configuration

```javascript
await ghosttrace.init({
  adminEmail: 'admin@company.com',
  adminPassword: 'secure-password',
  dashboardPort: 3001,
  blockThreshold: 70,
  rateLimit: 120,
  blockOnThreat: true,
  database: {
    type: 'postgres',
    host: 'localhost',
    port: 5432,
    name: 'myapp_ghosttrace',
    user: 'postgres',
    password: 'password',
  },
  ai: {
    provider: 'openai',
    apiKey: process.env.OPENAI_API_KEY,
    model: 'gpt-4o-mini',
  },
});
```

## 🎛️ Route-Specific Configuration

Apply different security levels to different routes:

```javascript
// Default protection
app.use('/api/posts', ghosttrace.secure());

// High security for authentication routes
app.use('/api/auth', ghosttrace.secure({ 
  riskThreshold: 50,      // More strict
  rateLimit: 20,          // Fewer requests allowed
}));

// Monitor only (don't block)
app.use('/api/public', ghosttrace.secure({ 
  blockOnThreat: false,   // Only log threats
}));

// Custom allowlist
app.use('/api/payments', ghosttrace.secure({
  riskThreshold: 40,      // Very strict for payments
  allowlist: ['/api/payments/webhook'],
}));
```

## 📚 Examples

See the `examples/` directory for complete integration examples:

### [express-basic.js](./examples/express-basic.js)
Minimal integration showing the essentials.

### [express-social-media.js](./examples/express-social-media.js)
Social media backend with authentication, posts, and profiles.

### [express-ecommerce.js](./examples/express-ecommerce.js)
E-commerce backend with products, cart, checkout, and admin routes.

Run an example:

```bash
cd examples
node express-social-media.js
```

## 🔧 Advanced Features

### Multi-Provider AI Fallback

Configure multiple AI providers with automatic fallback:

```javascript
// Set providers in the dashboard UI or via environment:
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GEMINI_API_KEY=...

// Or configure programmatically
await ghosttrace.init({
  // ... other config
  ai: {
    providers: [
      { provider: 'openai', apiKey: '...', priority: 1 },
      { provider: 'anthropic', apiKey: '...', priority: 2 },
      { provider: 'gemini', apiKey: '...', priority: 3 },
    ]
  }
});
```

### External Data Source Monitoring

Connect and monitor external databases for suspicious activity:

1. Open dashboard → **Data Sources**
2. Add connection (Postgres, MySQL, MongoDB, Redis)
3. Select tables/collections to monitor
4. Configure alert rules

### Custom Threat Handlers

Override default blocking behavior:

```javascript
const protectionMiddleware = require('ghosttrace/middleware/protection');

app.use(protectionMiddleware({
  blockOnThreat: true,
  onThreat: async (req, res, analysis) => {
    // Custom handling
    console.log(`Threat detected: ${analysis.riskScore}`);
    
    // Log to your system
    await logToExternalSIEM(analysis);
    
    // Custom response
    return res.status(403).json({
      error: 'Access denied',
      requestId: req.id,
    });
  }
}));
```

### Webhook Integrations

Ingest alerts from external systems:

```bash
curl -X POST http://localhost:3001/api/integrations/ingest \
  -H "Content-Type: application/json" \
  -d '{
    "source": "external-waf",
    "severity": "high",
    "message": "Suspicious activity detected",
    "metadata": { "ip": "1.2.3.4" }
  }'
```

## 🚀 Deployment Options

### As an npm Package (Recommended)

Install and integrate into your existing application:

```bash
npm install ghosttrace
```

```javascript
const ghosttrace = require('ghosttrace');
await ghosttrace.init({ /* config */ });
app.use('/api', ghosttrace.secure());
```

### As a Standalone Application

Run GhostTrace as a standalone SOC platform:

```bash
git clone https://github.com/yourusername/ghosttrace.git
cd ghosttrace
npm install
npm start
```

### Docker Deployment

```bash
docker compose up -d --build
```

See [DOCKER.md](./DOCKER.md) for details.

## 🛠️ API Reference

### `ghosttrace.init(config)`

Initialize GhostTrace security layer.

**Parameters:**
- `config.adminEmail` (required) - Admin user email
- `config.adminPassword` (required) - Admin user password (min 8 chars)
- `config.dashboardPort` (optional) - Dashboard server port (default: 3001)
- `config.blockThreshold` (optional) - Risk score threshold for blocking (default: 70)
- `config.rateLimit` (optional) - Max requests per minute (default: 120)
- `config.blockOnThreat` (optional) - Enable blocking (default: true)
- `config.database` (optional) - Database configuration object
- `config.ai` (optional) - AI provider configuration object

**Returns:** Promise<{ config, dashboardServer, stop }>

### `ghosttrace.secure(options)`

Create protection middleware for Express routes.

**Parameters:**
- `options.riskThreshold` (optional) - Override global risk threshold
- `options.rateLimit` (optional) - Override global rate limit
- `options.blockOnThreat` (optional) - Override global blocking behavior
- `options.allowlist` (optional) - Array of paths to skip protection

**Returns:** Express middleware function

### `ghosttrace.version`

Current version of GhostTrace.

## 📊 Dashboard API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/auth/login` | POST | Authenticate admin user |
| `/api/soc/command-center` | GET | Dashboard aggregates and KPIs |
| `/api/alerts` | GET | Alert queue (filterable) |
| `/api/alerts/:id` | PATCH | Update alert status |
| `/api/incidents` | GET | List incidents |
| `/api/incidents` | POST | Create incident |
| `/api/hunt/query` | POST | Threat hunt search |
| `/api/threats/analyze` | POST | Manual threat analysis |
| `/api/threats/feed` | GET | SSE live threat stream |
| `/api/integrations/ingest` | POST | External alert ingest |
| `/api/sources` | GET | List data sources |
| `/api/geo/stream` | GET | Live GeoIP events stream |

## 🧪 Testing Your Integration

1. Start your application with GhostTrace enabled
2. Access the dashboard at `http://localhost:3001`
3. Login with your admin credentials
4. Make requests to your protected routes
5. View real-time alerts in the dashboard

Test threat detection:

```bash
# SQL injection attempt
curl "http://localhost:3000/api/users?id=1' OR '1'='1"

# XSS attempt
curl -X POST http://localhost:3000/api/posts \
  -H "Content-Type: application/json" \
  -d '{"content": "<script>alert(1)</script>"}'

# Rate limit test
for i in {1..150}; do curl http://localhost:3000/api/users; done
```

Check the dashboard to see how GhostTrace detected and handled these threats.

## 🔒 Security Best Practices

1. **Never commit credentials** - Use environment variables or secrets management
2. **Use strong admin passwords** - Minimum 8 characters, mix of letters/numbers/symbols
3. **Enable HTTPS in production** - Set `NODE_ENV=production`
4. **Review alerts regularly** - Check dashboard daily for suspicious activity
5. **Tune thresholds** - Adjust `blockThreshold` based on your traffic patterns
6. **Enable database persistence** - Don't run in-memory only for production
7. **Configure AI providers** - Enable AI analysis for better threat detection
8. **Monitor rate limits** - Adjust `rateLimit` for your use case
9. **Use allowlists sparingly** - Only skip protection for truly public routes
10. **Keep GhostTrace updated** - Run `npm update ghosttrace` regularly

## 🤝 Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

## 📄 License

MIT License - see [LICENSE](./LICENSE) file for details.

## 🆘 Support

- 📖 [Documentation](https://github.com/yourusername/ghosttrace)
- 🐛 [Issue Tracker](https://github.com/yourusername/ghosttrace/issues)
- 💬 [Discussions](https://github.com/yourusername/ghosttrace/discussions)

---

**Built for defenders by defenders.** 🛡️

Star ⭐ this project if you find it useful!
